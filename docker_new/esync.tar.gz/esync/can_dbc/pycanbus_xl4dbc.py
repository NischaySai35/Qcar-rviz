import os,sys
import subprocess,time
import signal,traceback
import argparse
import can

import cantools
from pprint import pprint
#[message('ExampleMessage', 0x1f0, False, 8, 'Example message used as template in MotoHawk models.')]


parser = argparse.ArgumentParser()
parser.add_argument('-dbc', dest='dbc_filLocation', type=str, help="dbc file location")
parser.add_argument('-i', dest='interval_time', type=str, help='each CAN message send interval time')
parser.add_argument('-can', dest='interface', type=str,default="vcan0", help='each CAN message send interval time')
parser.add_argument('-f', dest='frame_name', type=str,default="Vehicle_Status", help='frame name')
parser.add_argument('-s', dest='signal_name', type=str,default={'VehicleSpeed': 80, 'Battery': 80, 'Ignition': 0}, help='signal name for each signal')


args = parser.parse_args()
dbcFilLocation = args.dbc_filLocation
intervalTime = args.interval_time
canInterface = args.interface
frame_name = args.frame_name
signal_name = args.signal_name


if os.path.isfile(dbcFilLocation):
    print(f"file present in the locaton {dbcFilLocation}")
    db = cantools.database.load_file(dbcFilLocation)
    print(db.messages)
    example_message = db.get_message_by_name('TireInfo')
    VehicleInfo = db.get_message_by_name('VehicleInfo')
    BatteryInfo = db.get_message_by_name('BatteryInfo')
    EngineInfo = db.get_message_by_name('EngineInfo')
    IgnitionInfo = db.get_message_by_name('IgnitionInfo')
    pprint(example_message.signals)
else:
    print(f"dbc file not available{dbcFilLocation}")
    sys.exit(0)


can_bus = can.interface.Bus(interface='socketcan', channel=canInterface)

count = 0
while 1:
    time.sleep(1)
    countSPD = count + 1
    countVOLT = 12
    countSOC = countVOLT + 1
    count = countSPD
    #data = example_message.encode({'VehicleSpeed': 10, 'StateofCharge': 80,"BatteryVoltage":12, 'IgnitionStatus': 0,"TirePressureFR":32, "TirePressureFL" :32, "TirePressureBR":32, "TirePressureBL":32, })
    data = example_message.encode(
        {"TirePressureFL": 39, "TirePressureBR": 29, "TirePressureBL": 29,"TirePressureFR":29,"TirePressureFRR":29})
    message = can.Message(arbitration_id=example_message.frame_id, data=data,is_extended_id=False)
    can_bus.send(message)

    data_VehicleSpeed = VehicleInfo.encode(
        {"Torque":0,"VehicleSpeed": 124,"IndoorTemp":0,"OutdoorTemp":0,"SteeringAngle":0})
    VehicleInfo_message = can.Message(arbitration_id=VehicleInfo.frame_id, data=data_VehicleSpeed,is_extended_id=False)
    can_bus.send(VehicleInfo_message)

    data_BatteryInfo = BatteryInfo.encode(
        {"StateofCharge":80,"BatteryTemp": 70,"BatteryVoltage":75})
    BatteryInfo_message = can.Message(arbitration_id=BatteryInfo.frame_id, data=data_BatteryInfo,is_extended_id=False)
    can_bus.send(BatteryInfo_message)

    data_IgnitionInfo=IgnitionInfo.encode(
        {"IgnitionStatus":1})
    IgnitionInfo_message = can.Message(arbitration_id=IgnitionInfo.frame_id, data=data_IgnitionInfo,is_extended_id=False)
    can_bus.send(IgnitionInfo_message)

    data_EngineInfo=EngineInfo.encode({"EnginePower":300,"EngineTemperature":190,"EngineSpeed":7000,"FuelConsumption":100})
    EngineInfo_message = can.Message(arbitration_id=EngineInfo.frame_id, data=data_EngineInfo,is_extended_id=False)
    can_bus.send(EngineInfo_message)


can_bus.shutdown()
