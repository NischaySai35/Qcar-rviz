#!/bin/bash -e
export PATH=$PATH:/sbin:/bin:/usr/sbin:/usr/bin

CMD=$(uname -a | grep -Po '(?<=Linux )(\S+)')
NUM=$(echo $CMD | cut -d '-' -f 2 )
SN=$(echo $NUM | cut -d '_' -f 1)

vin="$SN"

echo $vin 

