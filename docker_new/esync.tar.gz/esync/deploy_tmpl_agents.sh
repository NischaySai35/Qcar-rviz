#!/bin/bash
####################### TEMPLATE AGENTS DEPLOYMENT SCRIPT #########################

THIS_DIR="$(cd "$(dirname "$0")" && pwd)"
RUN_DIR="$THIS_DIR"
rdc='\033[0;31m'; grc='\033[0;32m'; ywc='\033[1;33m'; nc='\033[0m'

# Initialize variables
secondboardAvailable=true
AGENT_OP="NONE"
SELECT_BOARD=0
TMPL_UA_BOARD1=false
TMPL_UA_BOARD2=false

init_check() {
    if [ ! -f "$THIS_DIR/config.cfg" ]; then
        echo "config.cfg file not found at $THIS_DIR/config.cfg"
        exit 1
    fi
    if [ ! -f "$THIS_DIR/config_rpi.cfg" ]; then
        echo "config_rpi.cfg file not found at $THIS_DIR/config_rpi.cfg"
        exit 1
    fi
    if [ ! -f "$THIS_DIR/../sdk.cfg" ]; then
        echo "sdk.cfg file not found at $THIS_DIR/../"
        exit 1
    fi
    
    # Source config files
    . "$THIS_DIR/config.cfg"
    . "$THIS_DIR/config_rpi.cfg"
    . "$THIS_DIR/../sdk.cfg"
}

init_check

FILE_NAME=$(basename "$0")
PASS_CMD="sshpass -p $RPI_PASSWORD"
SSH_CMD="$RPI_USERNAME@$RPI_IP"
SUCCESS="STATUS : Success"
FAILED="STATUS : Failure"
logFile="$RUN_DIR/deploy_tmpl_agent.log"


usage() {
    echo "Usage: $FILE_NAME [start | reset] [UA] [sample_updateagent_path]"
    echo "Examples:"
    echo "  $FILE_NAME start UA                           # Use default path"
    echo "  $FILE_NAME start UA /path/to/sample_updateagent  # Use custom path"
    echo "  $FILE_NAME reset UA                           # Remove template agent"
    exit 1
}

sdk_install_check() {
    # Check if eSync is installed on the remote board
    if ! $PASS_CMD ssh -q $SSH_CMD "test -d \"$ESYNC_INSTALL_DIR/esync\""; then
        echo "eSync client SDK is not installed on $RPI_IP, install SDK first"
        echo "Expected path: $ESYNC_INSTALL_DIR/esync"
        echo "Please run: ./install_esync.sh -i on the target board"
        exit 1
    fi
    echo "eSync SDK found on $RPI_IP at $ESYNC_INSTALL_DIR/esync"
}

sdk_install_check

secondBoardConfigCheck() {
    if [ -z "$SECOND_RPI_PASSWORD" ] || [ -z "$SECOND_RPI_IP" ] || [ -z "$SECOND_RPI_USERNAME" ]; then
        secondboardAvailable=false
    fi
}

sshcommands() {
    BoardPass="sshpass -p $SECOND_RPI_PASSWORD"
    BoardCommand="$SECOND_RPI_USERNAME@$SECOND_RPI_IP"
}

checkBoard() {
    if [ "$1" == "deploy" ]; then
        echo -e " On which board do you want to deploy?"
    elif [ "$1" == "reset" ]; then
        echo -e " On which board do you want to reset?"
    fi
    echo -e " 1 - Rpi Board 1"
    echo -e " 2 - Rpi Board 2"
    read -r Board
    echo "DEBUG: Read input: '$Board'"
    if [ "$Board" = "1" ]; then
        SELECT_BOARD=1
        echo "Selected Board 1"
    elif [ "$Board" = "2" ]; then
        SELECT_BOARD=2
        echo "Selected Board 2"
    else
        printf "[ Error Wrong Input !!] Please provide either \"1\" or \"2\" \n" && exit 1
    fi
}

check_tmpl_bins_running() {
    $PASS_CMD ssh -q $SSH_CMD test -e "$ESYNC_INSTALL_DIR/esync/bin/$AGENT_BIN_NAME.org" && TMPL_UA_BOARD1=true
    if [ "$secondboardAvailable" == "true" ]; then
        sshcommands
        $BoardPass ssh -q $BoardCommand test -e "$SECOND_RPI_LOCATION_TO_COPY/esync/bin/$AGENT2_BIN_NAME.org" && TMPL_UA_BOARD2=true
    fi
}

create_ua_certs_file() {
    # Ensure local certificate config directory exists
    mkdir -p "$THIS_DIR/InVehicle-Certs/config"
    
    certsFile="$THIS_DIR/InVehicle-Certs/config/${TMPL_UA_CERTS_NAME}_cert.cfg"
    
    # Create fresh certificate config file
    cat > "$certsFile" << EOF
#This configuration file is read while creating x509 certificates.

CERT_TYPE="UA"
LABEL_NAME="$TMPL_UA_CERTS_NAME"
UA_ADDR="$TMPL_UA_PKG_TYPE"
EOF
    echo "Created certificate config: $certsFile"
    
    # Ensure remote certificate directories exist
    $PASS_CMD ssh -o StrictHostKeyChecking=no $SSH_CMD "mkdir -p $ESYNC_INSTALL_DIR/esync/InVehicle-Certs/config"
    $PASS_CMD ssh -o StrictHostKeyChecking=no $SSH_CMD "mkdir -p $ESYNC_RUN_DIR/InVehicle-Certs/pki/certs"
    $PASS_CMD ssh -o StrictHostKeyChecking=no $SSH_CMD "mkdir -p $ESYNC_RUN_DIR/log"
}

check_remote_broker_config() {
    local board_num=$1
    local config_file="$SAMPLE_UA_DIR/config.cmk"
    
    if [ ! -f "$config_file" ]; then
        echo "config.cmk not found at $config_file"
        exit 1
    fi
    
    local remote_broker_enabled=false
    if grep -q "^set (REMOTE_BROKER true)" "$config_file"; then
        remote_broker_enabled=true
    fi
    
    if [ "$board_num" == "1" ] && [ "$remote_broker_enabled" == "true" ]; then
        echo "ERROR: Board 1 requires REMOTE_BROKER to be disabled (commented out) in config.cmk"
        echo "Please comment out 'set (REMOTE_BROKER true)' and rebuild"
        exit 1
    elif [ "$board_num" == "2" ] && [ "$remote_broker_enabled" == "false" ]; then
        echo "ERROR: Board 2 requires REMOTE_BROKER to be enabled in config.cmk"
        echo "Please uncomment 'set (REMOTE_BROKER true)' and rebuild"
        exit 1
    fi
    
    echo "REMOTE_BROKER configuration correct for Board $board_num"
}

check_ua_config() {
    # Check REMOTE_BROKER configuration
    check_remote_broker_config "$SELECT_BOARD"
    agentBin="$SAMPLE_UA_DIR/build/$TMPL_UA_BIN_NAME"
    if [ ! -f "$agentBin" ]; then
        echo "$TMPL_UA_BIN_NAME binary file not found at $agentBin"
        echo "Use: $FILE_NAME start UA /path/to/sample_updateagent"
        exit 1
    fi
    echo "Template agent binary found: $agentBin"
}

stop_agents() {
    $PASS_CMD ssh -o StrictHostKeyChecking=no $SSH_CMD "$ESYNC_INSTALL_DIR/esync/start.sh -k" && echo "$SUCCESS, eSync stopped" >> "$logFile" || echo "$FAILED, eSync stop failed" >> "$logFile"
}

start_agent() {
    $PASS_CMD ssh -o StrictHostKeyChecking=no $SSH_CMD "$ESYNC_INSTALL_DIR/esync/start.sh -s" && echo "$SUCCESS, eSync started" >> "$logFile" || echo "$FAILED, eSync start failed" >> "$logFile"
    
    if [ "$SELECT_BOARD" == "2" ]; then
        run_agent_board_2 "$1"
    elif [ "$SELECT_BOARD" == "1" ]; then
        # Ensure log directory exists on remote system
        $PASS_CMD ssh -o StrictHostKeyChecking=no $SSH_CMD "mkdir -p $ESYNC_RUN_DIR/log"
        $PASS_CMD ssh -o StrictHostKeyChecking=no $SSH_CMD "$ESYNC_INSTALL_DIR/esync/start_agent.sh start $1"
    fi
}

copy_tmpl_ua() {
    agentBin="$SAMPLE_UA_DIR/build/$TMPL_UA_BIN_NAME"
    certsFile="$THIS_DIR/InVehicle-Certs/config/${TMPL_UA_CERTS_NAME}_cert.cfg"
    
    $PASS_CMD ssh $SSH_CMD test -e "$ESYNC_INSTALL_DIR/esync/bin/$AGENT_BIN_NAME.org"
    if [ ! $? -eq 0 ]; then
        if [ -f "$agentBin" ] && [ -f "$certsFile" ]; then
            $PASS_CMD ssh $SSH_CMD mv "$ESYNC_INSTALL_DIR/esync/bin/$AGENT_BIN_NAME" "$ESYNC_INSTALL_DIR/esync/bin/$AGENT_BIN_NAME.org" && echo "$SUCCESS, $AGENT_BIN_NAME renamed to $AGENT_BIN_NAME.org" >> "$logFile"
            $PASS_CMD scp "$agentBin" "$SSH_CMD:$ESYNC_INSTALL_DIR/esync/bin/$AGENT_BIN_NAME" && echo "$SUCCESS, $TMPL_UA_BIN_NAME copied as $AGENT_BIN_NAME" >> "$logFile"
            $PASS_CMD scp "$certsFile" "$SSH_CMD:$ESYNC_INSTALL_DIR/esync/InVehicle-Certs/config/" && echo "$SUCCESS, certificate config copied" >> "$logFile"
        else
            echo "Agent binary or certificate config file not found"
            exit 1
        fi
    else
        echo "Already template agent binary is running"
    fi
}

dirCreationOnboard_2() {
    secondBoardDir="$SECOND_RPI_LOCATION_TO_COPY/esync"
    secondBoardCerts="$SECOND_RPI_LOCATION_TO_COPY/esync/data/InVehicle-Certs"
    
    $BoardPass ssh $BoardCommand "mkdir -p $secondBoardDir/bin/"
    $BoardPass ssh $BoardCommand "mkdir -p $secondBoardCerts/pki/certs/"
    $BoardPass ssh $BoardCommand "mkdir -p $SECOND_RPI_LOCATION_TO_COPY/esync/data/log/"
    $BoardPass ssh $BoardCommand "chmod -R 777 $secondBoardDir/"
}

copy_tmpl_ua_2() {
    agentBin="$SAMPLE_UA_DIR/build/$TMPL_UA_BIN_NAME"
    certsFile="$THIS_DIR/InVehicle-Certs/config/${TMPL_UA_CERTS_NAME}_cert.cfg"
    
    if [ -f "$agentBin" ] && [ -f "$certsFile" ]; then
        sshcommands
        secondBoardDir="$SECOND_RPI_LOCATION_TO_COPY/esync"
        
        if ! $BoardPass ssh $BoardCommand [ -d "$secondBoardDir" ]; then
            dirCreationOnboard_2
        fi
        
        $BoardPass ssh $BoardCommand mv "$secondBoardDir/bin/$AGENT2_BIN_NAME" "$secondBoardDir/bin/$AGENT2_BIN_NAME.org" 2>/dev/null || true
        $BoardPass scp "$agentBin" "$BoardCommand:$secondBoardDir/bin/$TMPL_UA_BIN_NAME" && echo "$SUCCESS, $TMPL_UA_BIN_NAME copied to board 2" >> "$logFile"
        $BoardPass scp -r "$THIS_DIR/lib/" "$BoardCommand:$secondBoardDir/" && echo "$SUCCESS, libraries copied to board 2" >> "$logFile"
        $BoardPass scp "$THIS_DIR/start_agent.sh" "$BoardCommand:$secondBoardDir/" && echo "$SUCCESS, start script copied to board 2" >> "$logFile"
        # Copy config files to Board 2
        $BoardPass scp "$THIS_DIR/config.cfg" "$BoardCommand:$secondBoardDir/" && echo "$SUCCESS, config.cfg copied to board 2" >> "$logFile"
        $BoardPass scp "$THIS_DIR/config_rpi.cfg" "$BoardCommand:$secondBoardDir/" && echo "$SUCCESS, config_rpi.cfg copied to board 2" >> "$logFile"
        $BoardPass scp "$THIS_DIR/config_rpi.cfg" "$BoardCommand:$secondBoardDir/data/" && echo "$SUCCESS, config_rpi.cfg copied to board 2 data dir" >> "$logFile"
        $BoardPass scp "$THIS_DIR/../sdk.cfg" "$BoardCommand:$secondBoardDir/" && echo "$SUCCESS, sdk.cfg copied to board 2" >> "$logFile"
        # Copy certificate config to Board 2
        $BoardPass ssh $BoardCommand "mkdir -p $secondBoardDir/InVehicle-Certs/config/"
        $BoardPass scp "$certsFile" "$BoardCommand:$secondBoardDir/InVehicle-Certs/config/" && echo "$SUCCESS, certificate config copied to board 2" >> "$logFile"
        $BoardPass ssh $BoardCommand "chmod -R 777 $secondBoardDir/"
    else
        echo "Agent binary or certificate config file not found" && exit 1
    fi
}

generate_board1_certs() {
    echo "Generating certificates on Board 1 for Board 2 deployment..."
    
    # Copy certificate config to Board 1
    certsFile="$THIS_DIR/InVehicle-Certs/config/${TMPL_UA_CERTS_NAME}_cert.cfg"
    $PASS_CMD scp "$certsFile" "$SSH_CMD:$ESYNC_INSTALL_DIR/esync/InVehicle-Certs/config/" && echo "Certificate config copied to Board 1"
    
    # Stop eSync and remove data directory
    $PASS_CMD ssh -o StrictHostKeyChecking=no $SSH_CMD "$ESYNC_INSTALL_DIR/esync/start.sh -k" 2>/dev/null || true
    $PASS_CMD ssh $SSH_CMD "rm -rf $ESYNC_INSTALL_DIR/esync/data/" && echo "Removed existing data directory"
    
    # Start eSync with -s -w flags to generate certificates
    $PASS_CMD ssh -o StrictHostKeyChecking=no $SSH_CMD "$ESYNC_INSTALL_DIR/esync/start.sh -s -w" && echo "eSync started with certificate generation"
    sleep 10  # Wait for certificate generation
    
    # Verify certificates were created
    if $PASS_CMD ssh -q $SSH_CMD "test -d \"$ESYNC_INSTALL_DIR/esync/data/InVehicle-Certs/pki/certs/$TMPL_UA_CERTS_NAME\""; then
        echo "Certificates generated successfully on Board 1"
    else
        echo "Failed to generate certificates on Board 1"
        exit 1
    fi
}

copy_certs() {
    sshcommands
    
    # Generate certificates on Board 1
    generate_board1_certs
    
    # Copy entire InVehicle-Certs directory from Board 1 to Board 2
    if $PASS_CMD ssh $SSH_CMD [ -d "$ESYNC_INSTALL_DIR/esync/data/InVehicle-Certs" ]; then
        # Create temp directory for certificate transfer
        rm -rf "$THIS_DIR/temp_certs" 2>/dev/null || true
        mkdir -p "$THIS_DIR/temp_certs"
        
        # Download entire InVehicle-Certs from Board 1
        $PASS_CMD scp -r "$SSH_CMD:$ESYNC_INSTALL_DIR/esync/data/InVehicle-Certs" "$THIS_DIR/temp_certs/" && echo "Downloaded certificates from Board 1"
        
        # Upload to Board 2
        $BoardPass scp -r "$THIS_DIR/temp_certs/InVehicle-Certs" "$BoardCommand:$SECOND_RPI_LOCATION_TO_COPY/esync/data/" && echo "$SUCCESS, certificates copied to board 2" >> "$logFile"
        
        # Cleanup
        rm -rf "$THIS_DIR/temp_certs" 2>/dev/null || true
    else
        echo "Certificates not found on Board 1" && exit 1
    fi
}

run_agent_board_2() {
    # Copy certificates from Board 1 to Board 2
    copy_certs
    
    sshcommands
    # Start template agent with remote broker connection
    TCP_CONNECTION="tcp://$RPI_IP:$PORT_ADDRESS"
    echo "Starting template agent on Board 2 with connection to $TCP_CONNECTION"
    
    # Kill any existing template agents on Board 2
    $BoardPass ssh $BoardCommand "pkill -f $TMPL_UA_BIN_NAME" 2>/dev/null || true
    sleep 2
    
    # Start template agent in background with timeout
    timeout 10 $BoardPass ssh -o ConnectTimeout=5 $BoardCommand "cd $SECOND_RPI_LOCATION_TO_COPY/esync && export LD_LIBRARY_PATH=$SECOND_RPI_LOCATION_TO_COPY/esync/lib:\$LD_LIBRARY_PATH && nohup ./bin/$TMPL_UA_BIN_NAME -k data/InVehicle-Certs/pki/certs/$TMPL_UA_CERTS_NAME -t $TMPL_UA_PKG_TYPE -b data/ -u $TCP_CONNECTION -i -D > data/log/$TMPL_UA_BIN_NAME.log 2>&1 & echo 'Agent started'" || echo "Command timed out (agent may still be starting)"
    
    sleep 3
    
    # Check if agent is running
    if $BoardPass ssh $BoardCommand "ps aux | grep $TMPL_UA_BIN_NAME | grep -v grep" > /dev/null; then
        echo "✅ Template agent started successfully on Board 2"
    else
        echo "❌ Template agent may not have started on Board 2"
    fi
}

clean_ua_files() {
    $PASS_CMD ssh $SSH_CMD test -e "$ESYNC_INSTALL_DIR/esync/bin/$AGENT_BIN_NAME.org"
    if [ $? -eq 0 ]; then
        $PASS_CMD ssh $SSH_CMD "pkill -f $AGENT_BIN_NAME" 2>/dev/null || true
        $PASS_CMD ssh $SSH_CMD rm -rf "$ESYNC_INSTALL_DIR/esync/bin/$AGENT_BIN_NAME" && echo "$SUCCESS, template $AGENT_BIN_NAME removed" >> "$logFile"
        $PASS_CMD ssh $SSH_CMD mv "$ESYNC_INSTALL_DIR/esync/bin/$AGENT_BIN_NAME.org" "$ESYNC_INSTALL_DIR/esync/bin/$AGENT_BIN_NAME" && echo "$SUCCESS, original $AGENT_BIN_NAME restored" >> "$logFile"
    else
        echo "Already default agent binary is running"
    fi
}

clean_agent_files_board_2() {
    sshcommands
    $BoardPass ssh $BoardCommand "pkill -f $TMPL_UA_BIN_NAME" 2>/dev/null || true
    $BoardPass ssh $BoardCommand mv "$SECOND_RPI_LOCATION_TO_COPY/esync/bin/$AGENT2_BIN_NAME.org" "$SECOND_RPI_LOCATION_TO_COPY/esync/bin/$AGENT2_BIN_NAME" 2>/dev/null || true
    $BoardPass ssh $BoardCommand rm -rf "$SECOND_RPI_LOCATION_TO_COPY/esync/bin/$TMPL_UA_BIN_NAME" && echo "$SUCCESS, $TMPL_UA_BIN_NAME removed from board 2" >> "$logFile"
}

tmpl_ua_setup() {
    if [ "$SELECT_BOARD" == "1" ]; then
        if [ "$1" == "start" ]; then
            echo "Installing on RPI Board 1"
            stop_agents
            copy_tmpl_ua
        elif [ "$1" == "stop" ]; then
            stop_agents
            clean_ua_files
        fi
    elif [ "$SELECT_BOARD" == "2" ]; then
        if [ "$1" == "start" ]; then
            secondBoardConfigCheck
            if [ "$secondboardAvailable" == "true" ]; then
                echo "Installing on RPI Board 2"
                stop_agents
                copy_tmpl_ua_2
            else
                printf "$rdc Second board configuration not updated in config_rpi.cfg file $nc \n" && exit 1
            fi
        elif [ "$1" == "stop" ]; then
            stop_agents
            clean_agent_files_board_2
        fi
    fi
}

# Main execution
if [ $# -ge 2 ] && ([ "$1" = "start" ] || [ "$1" = "reset" ]) && [ "$2" = "UA" ]; then
    AGENT_OP="$2"
    OP1="$1"
    
    # Set sample_updateagent directory path
    if [ $# -eq 3 ]; then
        SAMPLE_UA_DIR="$3"
    else
        SAMPLE_UA_DIR="$THIS_DIR/sample_updateagent"
    fi
    
    case "$1" in
    start)
        printf "$ywc Installing custom agents please wait...$nc\n"
        checkBoard "deploy"
        check_tmpl_bins_running
        
        create_ua_certs_file
        check_ua_config
        
        if [ "$SELECT_BOARD" == "1" ]; then
            # Restore original agent if template was deployed
            if [ "$TMPL_UA_BOARD1" == "true" ]; then
                echo "Restoring original agent to generate certificates..."
                clean_ua_files
            fi
            
            # Copy certificate config
            certsFile="$THIS_DIR/InVehicle-Certs/config/${TMPL_UA_CERTS_NAME}_cert.cfg"
            $PASS_CMD scp "$certsFile" "$SSH_CMD:$ESYNC_INSTALL_DIR/esync/InVehicle-Certs/config/"
            
            # Check if certificates exist, create if needed
            if ! $PASS_CMD ssh -q $SSH_CMD "test -d \"$ESYNC_RUN_DIR/InVehicle-Certs/pki/certs/$TMPL_UA_CERTS_NAME\""; then
                echo "Creating tmpl_ua certificates..."
                $PASS_CMD ssh $SSH_CMD "cp -r $ESYNC_RUN_DIR/InVehicle-Certs/pki/certs/agent $ESYNC_RUN_DIR/InVehicle-Certs/pki/certs/$TMPL_UA_CERTS_NAME"
                if $PASS_CMD ssh -q $SSH_CMD "test -d \"$ESYNC_RUN_DIR/InVehicle-Certs/pki/certs/$TMPL_UA_CERTS_NAME\""; then
                    echo "Certificates created successfully"
                else
                    echo "Failed to create certificates"
                    exit 1
                fi
            else
                echo "Certificates already exist"
            fi
            
            # Now deploy template agent
            stop_agents
            copy_tmpl_ua
            # For Board 1, start eSync normally (template agent renamed as 'agent')
            $PASS_CMD ssh -o StrictHostKeyChecking=no $SSH_CMD "$ESYNC_INSTALL_DIR/esync/start.sh -s" && echo "$SUCCESS, eSync started with template agent" >> "$logFile" || echo "$FAILED, eSync start failed" >> "$logFile"
        else
            # Copy certificate config to Board 1 (broker) for Board 2 deployment
            certsFile="$THIS_DIR/InVehicle-Certs/config/${TMPL_UA_CERTS_NAME}_cert.cfg"
            $PASS_CMD scp "$certsFile" "$SSH_CMD:$ESYNC_INSTALL_DIR/esync/InVehicle-Certs/config/" && echo "$SUCCESS, certificate config copied to Board 1" >> "$logFile"
            
            tmpl_ua_setup "start"
            start_agent "UA"
        fi
        
        printf "$grc Custom agent deployed successfully $nc \n"
        ;;
        
    reset)
        printf "$ywc Resetting custom agents please wait... $nc \n"
        checkBoard "reset"
        check_tmpl_bins_running
        
        tmpl_ua_setup "stop"
        # Just start eSync without trying to start template agent
        $PASS_CMD ssh -o StrictHostKeyChecking=no $SSH_CMD "$ESYNC_INSTALL_DIR/esync/start.sh -s" && echo "$SUCCESS, eSync started" >> "$logFile" || echo "$FAILED, eSync start failed" >> "$logFile"
        
        printf "$grc Custom agent reset successfully $nc \n"
        ;;
        
    *)
        usage
        ;;
    esac
else
    usage
fi