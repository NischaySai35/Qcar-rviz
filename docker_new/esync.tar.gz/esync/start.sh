#!/bin/bash -e
##################################
# Script Name: start.sh
# Description: Start eDatX/eSync Component
# Author: Rahul Patel
# Email: rahul.patel@excelfore.com
# Date: 03-06-2023
# Copyright: Excelfore Corportion (C) 2023
##################################

red=196; green=40; yellow=190; magenta=93; cyan=87; normal=0

clc() {
    printf "\033[38;5;${1}m"
}

print_usage()
{
    echo "Usage: $0 [-o <es_home>] [-d <es_data>] [-l <es_log>] [-s] [-k] [-a] [-S] [-w] [-q] [-v] [-b] [-c] [-Q]"
    echo "Options:"
    echo "  -o <es_home>: Set ESYNC_HOME directory"
    echo "  -d <es_data>: Set ESYNC_DATA directory"
    echo "  -l <es_log>: Set ESYNC_LOG directory"
    echo "  -s: Start ESYNC Apps"
    echo "  -k: Stop ESYNC Apps"
    echo "  -a: Stop ESYNC APPS only selfupdate required"
    echo "  -S: start ESYNC APPS when runs through selfupdateagent"
    echo "  -w: Wait for ESYNC to start"
    echo "  -q: Quiet mode (suppress output)"
    echo "  -v: Verbose mode (show detailed commands)"
    echo "  -b: Do not stop Start.sh script (use with -s)"
    echo "  -c: Start CAN ECU Simulator"
    echo "  -Q: Test mode (use esyncboot_test.json, launch esync_test_client only)"
    exit 1
}

printc() {
    local color=$1; shift
    local ctrl
    ctrl=$(clc "$color")
    local res='\033[0m'
    local fmt=$1; shift
    [ "$color" = 0 ] && ctrl=$res
    printf "${ctrl}${fmt}${res}\n" "$@"
}

readKey() {
    local key=$1
    local value
    value=$(node_editor -t "$ESYNC_DMTREE_LINK" -W "$key" -c > /dev/null 2>&1)
    echo "$value"
}

writeKey() {
    local key=$1
    local value=$2
    node_editor -t "$ESYNC_DMTREE_LINK" -W "$key" -T chr -V "$value" -c > /dev/null 2>&1
}

report_vin()
{
    vin=$(cat "$ESYNC_DMTREE_LINK/DevInfo/DevId/value" | sed s/.*://)
    echo "$vin"
}

parse_json_cfg() {
    json_file=$1
    export app_restart__stop_apps=$(jq -r '.services | keys[]' "$json_file" | tr '\n' ' ')
}

check_dependencies()
{
    local missing=""
    local cmd

    # Check for critical system commands
    for cmd in jq ip ping; do
        if ! command -v $cmd >/dev/null 2>&1; then
            missing="$missing $cmd"
        fi
    done

    # Check for eSync-specific tools (may not be in PATH yet)
    if [ -n "$ESYNC_HOME_DIR" ]; then
        for cmd in node_editor proc_man; do
            if [ ! -x "$ESYNC_HOME_DIR/bin/$cmd" ] && ! command -v $cmd >/dev/null 2>&1; then
                missing="$missing $cmd"
            fi
        done
    fi

    if [ -n "$missing" ]; then
        printc $red "Missing required dependencies:$missing"
        printc $yellow "Please install missing tools or verify ESYNC_HOME_DIR is set correctly"
        return 1
    fi
    return 0
}

verify_internet_connection()
{
    local ifc=$1
    # Try IP-based ping first (works without DNS), then DNS-based
    if ping -c 1 -W 2 -I "$ifc" 8.8.8.8 >/dev/null 2>&1 || \
       ping -c 1 -W 2 -I "$ifc" google.com >/dev/null 2>&1; then
        return 0
    fi
    return 1
}

# Global variable to store CAN simulator PID
CAN_SIM_PID=""

THIS_DIR="$(realpath "$(dirname "$0")")"

ES_HOME=$THIS_DIR
ES_DATA=$THIS_DIR
ES_LOG=$HOME/esync/log

init()
{
    # Verify all required dependencies are available
    check_dependencies || return 1

    mkdir -p $ESYNC_DATA_DIR/InVehicle-Certs/dm_tree
    mkdir -p $ESYNC_DATA_DIR/InVehicle-Certs/pki
    #mkdir -p $ESYNC_DATA_DIR/misc/ota_events
    #mkdir -p $ESYNC_DATA_DIR/misc/records/ecu_version
    mkdir -p $ESYNC_DATA_DIR/etc
    #mkdir -p $ESYNC_DATA_DIR/misc/certs_server
    mkdir -p $ESYNC_PROVISION_DIR
    mkdir -p $ESYNC_LOG_DIR
    # Create workload-agent directories (required for update agent)
    mkdir -p $ESYNC_DATA_DIR/workload-agent/install
    mkdir -p $ESYNC_DATA_DIR/backup
    mkdir -p $ESYNC_DATA_DIR/download

    # Check if docker tracking flag exists and create docker-image.cfg file
    DOCKER_TRACK_FLAG="$ESYNC_HOME_DIR/.docker_image_track"
    DOCKER_CONFIG_FILE="$ESYNC_DATA_DIR/workload-agent/docker-image.cfg"
    if [ -f "$DOCKER_TRACK_FLAG" ]; then
        cp "$DOCKER_TRACK_FLAG" "$DOCKER_CONFIG_FILE" 2>/dev/null
    fi

    export ESYNC_LOG_CFG="-L $ESYNC_DIR/etc/config/logcfg.json -l $ESYNC_LOG_DIR/"
    export ESYNC_LOG_ROTATE="$ESYNC_DIR/bin/loggit -p $ESYNC_LOG_CFG"

    for f in "$ESYNC_HOME_DIR/compilance/client.json" "$ESYNC_HOME_DIR/compilance/UA.json"; do
        [ -f "$f" ] && sed -i "s|\$ESYNC_DATA_DIR|${ESYNC_DATA_DIR}|g" "$f"
    done

    OPENSSL_CNF_PATH="$ESYNC_HOME_DIR/etc/openssl/openssl.cnf.dist"
    unset OPENSSL_CONF
    export OPENSSL_CONF="$OPENSSL_CNF_PATH"
}

setup_vcan0() {
    if ! ip link show vcan0 >/dev/null 2>&1; then
        printc $cyan "Setting up vcan0 interface..."
        if ! sudo ip link add dev vcan0 type vcan 2>/dev/null; then
            printc $red "ERROR: Failed to create vcan0 interface. Please check sudo permissions."
            return 1
        fi
        if ! sudo ip link set up vcan0 2>/dev/null; then
            printc $red "ERROR: Failed to activate vcan0 interface. Please check sudo permissions."
            return 1
        fi
        printc $green "vcan0 interface created and activated"
    else
        printc $green "vcan0 interface already exists"
        if ! sudo ip link set up vcan0 2>/dev/null; then
            printc $red "ERROR: Failed to activate existing vcan0 interface. Please check sudo permissions."
            return 1
        fi
    fi
    return 0
}

start()
{
    init
    old_loggit_pid=""
    if $SELF_UPDATE; then
        old_loggit_pid=$(ps -ef | grep -E "loggit.*selfupdateagent\.log" | grep -v grep | awk '{print $2}' || true)
    else
        stop
    fi

    # Load start.cfg first so ESYNC_NETWORK_INTERFACE can be overridden
    if [ -f "$ESYNC_HOME_DIR/start.cfg" ]; then
        . "$ESYNC_HOME_DIR/start.cfg"
    fi

    # Use user override if specified
    if [ -n "$ESYNC_NETWORK_INTERFACE" ]; then
        if ip link show "$ESYNC_NETWORK_INTERFACE" >/dev/null 2>&1; then
            netifc="$ESYNC_NETWORK_INTERFACE"
            # Verify manually configured interface is UP
            if ! ip link show "$netifc" 2>/dev/null | grep -q "state UP"; then
                printc $yellow "Warning: Configured interface $netifc is not UP"
            fi
            printc $green "Using configured interface: $netifc"
        else
            printc $yellow "Warning: Interface $ESYNC_NETWORK_INTERFACE not found, auto-detecting..."
            unset netifc
        fi
    fi
    
     # Auto-detect network interface if not set
    if [ -z "$netifc" ]; then
        netifc=$(ip route get 8.8.8.8 2>/dev/null | awk '/dev/ {print $5}')
        if [ -z "$netifc" ]; then
            netifc=$(ip route | awk '/default/ {print $5}' | head -n 1)
        fi
        if [ -z "$netifc" ]; then
            netifc=$(ip -brief link | awk '$2 == "UP" && $1 !~ /^(lo|docker|veth|br-|virbr|vmnet|can|slcan)/ {print $1}' | head -n 1)
        fi
        if [ -z "$netifc" ]; then
            netifc="eth0"
            printc $yellow "Warning: Could not auto-detect network interface, using default: $netifc"
        else
            printc $green "Auto-detected network interface: $netifc"
        fi
    fi

    # Verify internet connectivity with retry
    max_attempts=3
    attempt=1
    connectivity_ok=false
    while [ $attempt -le $max_attempts ]; do
        if verify_internet_connection "$netifc"; then
            printc $green "Interface $netifc has internet connectivity"
            connectivity_ok=true
            break
        else
            if [ $attempt -lt $max_attempts ]; then
                printc $yellow "No internet on $netifc, retrying ($attempt/$max_attempts)..."
                sleep 2
            else
                printc $yellow "Warning: Interface $netifc failed connectivity test"
            fi
        fi
        attempt=$((attempt + 1))
    done

    # Detect transport interface (interface with default route for provisioning)
    transport_ifc=$(ip route get 8.8.8.8 2>/dev/null | awk '/dev/ {print $5}')
    if [ -z "$transport_ifc" ]; then
        transport_ifc=$(ip route | awk '/default/ {print $5}' | head -n 1)
    fi

    printc $cyan "========================================"
    printc $cyan "Network Configuration"
    printc $cyan "========================================"

    if [ "$netifc" != "$transport_ifc" ] && [ -n "$transport_ifc" ]; then
        printc $normal "Default Route Interface: $transport_ifc (Starting eSync provisioning from default route)"
        printc $yellow "Note: Device identity from $netifc, default route via $transport_ifc"
    else
        printc $normal "Default Route Interface: $netifc (Starting eSync provisioning from default route)"
        if ! $connectivity_ok; then
            printc $yellow "Warning: No internet connectivity detected"
        fi
    fi
    printc $cyan "========================================"

    export CYCLONEDDS_URI="file://$ESYNC_HOME_DIR/etc/config/esync_dds_config.xml"
    ESYNC_BOOT="$ESYNC_HOME_DIR/bin/esync-boot"
    CAN_ECU_SIMULATOR="$ESYNC_HOME_DIR/bin/can_ecu_simulator"

    boot_args="-o $ESYNC_HOME_DIR -d $ESYNC_DATA_DIR -c $BOOT_CFG -s $ESYNC_HOME_DIR/provision.bin -vv -l $ESYNC_LOG_DIR/esync_boot.log"

    provisioned=false
    if [ -d $ESYNC_DMTREE_LINK ]; then
        printc $green "dmtree already present id=$(report_vin)"
        boot_args="$boot_args -p"
        provisioned=true
    fi
    
    if ! $provisioned; then
       INPUT_FILE="$ESYNC_HOME_DIR/provision-key.json"
       OUTPUT_FILE="$ESYNC_HOME_DIR/provision.bin"

       # Run OpenSSL encryption
       openssl enc -aes-256-ecb -e -K "$PROVISION_KEY" -in "$INPUT_FILE" -out "$OUTPUT_FILE"
       if [ -f "$OUTPUT_FILE" ]; then
            echo "Provision.bin created at $OUTPUT_FILE"
       else
            echo "ERROR: provision.bin not created"
       fi
    fi

    export ESYNC_DMTREE_LINK
    export ESYNC_NODES_LINK
    export ESYNC_LOG_CFG
    export ESYNC_LOG

    if $VERBOSE; then
        printc $green "Running $ESYNC_BOOT $boot_args"
    else
        printc $green "Starting eSync boot manager..."
    fi
    $ESYNC_BOOT $boot_args > /dev/null 2>&1 &
    esync_boot_pid=$!

    # Wait and verify esync-boot started successfully
    sleep 3
    if ! kill -0 $esync_boot_pid 2>/dev/null; then
        printc $red "Error: esync-boot failed to start (PID $esync_boot_pid exited)"
        return 1
    fi

    # Verify with proc_man
    PROC_MAN="$ESYNC_HOME_DIR/bin/proc_man"
    boot_running_pid=$("$PROC_MAN" -s esync-boot)
    if [ -z "$boot_running_pid" ]; then
        printc $red "Error: esync-boot not detected by proc_man"
        return 1
    fi

    printc $green "esync-boot started successfully (PID: $boot_running_pid)"

    if $START_CAN_SIM; then
        # Stop any existing CAN simulator first
        existing_can_pids=$(ps aux | grep can_ecu_simulator | grep -v grep | awk '{print $2}')
        if [ -n "$existing_can_pids" ]; then
            printc $yellow "Stopping existing CAN simulator processes: $existing_can_pids"
            echo $existing_can_pids | xargs kill -9 2>/dev/null || true
            sleep 1
        fi
        
        if setup_vcan0; then
            JSON_CONFIG="$ESYNC_DIR/ecu_config/inventory.json"
            CAN_SIM_CONFIG="$ESYNC_DIR/ecu_config/cfg_ecu_sim.json"

	    REQ_ID=$(jq -r '.Inventory.ecus["ecu-config"][0]["phy-req-add"] | ltrimstr("0x")' "$JSON_CONFIG")
	    RESP_ID=$(jq -r '.Inventory.ecus["ecu-config"][0]["phy-resp-add"] | ltrimstr("0x")' "$JSON_CONFIG")
	    CANDEV=$(jq -r '.Inventory.ecus["ecu-config"][0].interface' "$JSON_CONFIG")
            
            jq --arg req "$REQ_ID" --arg resp "$RESP_ID" '.uds.TesterPresent.ReqData = $req | .uds.TesterPresent.RespData = $resp' $CAN_SIM_CONFIG > ${CAN_SIM_CONFIG}.tmp && mv ${CAN_SIM_CONFIG}.tmp $CAN_SIM_CONFIG
            can_sim_args="-d $CANDEV -r $REQ_ID -t $RESP_ID -b 15 -s 0 -p 0xAA -vv -c $CAN_SIM_CONFIG"
            printc $green "Running $CAN_ECU_SIMULATOR $can_sim_args"
            $CAN_ECU_SIMULATOR $can_sim_args > $ESYNC_LOG_DIR/can_ecu_simulator.log 2>&1 &
            CAN_SIM_PID=$!
            printc $green "CAN simulator started with PID: $CAN_SIM_PID"
        else
            printc $red "CAN ECU Simulator cannot start due to vcan0 setup failure."
            printc $yellow "Please ensure you have sudo permissions."
        fi
    fi

    if $SELF_UPDATE && [ -n "$old_loggit_pid" ]; then
        sleep 1
        # Kill the specific old loggit by PID (before new selfupdateagent starts its loggit)
        if kill -0 "$old_loggit_pid" 2>/dev/null; then
           kill -9 "$old_loggit_pid" 2>/dev/null || true
        fi
    fi

    if $provisioned; then
        return 0
    fi

    sleep 2

    # Setup the dmtree links
    ln -snf "$ESYNC_DATA_DIR/InVehicle-Certs/dm_tree" "$ESYNC_DMTREE_LINK"
    ln -snf "$ESYNC_DATA_DIR/InVehicle-Certs/pki/certs" "$ESYNC_NODES_LINK"
    ln -snf "$ESYNC_DIR/etc/certs/Excelfore-CA.pem" "$ESYNC_PROVISION_DIR/edatx-ca.pem"
}

stop()
{
    # Use stored PID first, then fallback to process search
    if [ -n "$CAN_SIM_PID" ] && kill -0 "$CAN_SIM_PID" 2>/dev/null; then
        printc $yellow "Stopping CAN simulator with stored PID: $CAN_SIM_PID"
        kill -9 "$CAN_SIM_PID" 2>/dev/null || true
        CAN_SIM_PID=""
        sleep 1
    fi
    
    # Fallback: kill any remaining CAN simulator processes
    can_sim_pids=$(ps aux | grep can_ecu_simulator | grep -v grep | awk '{print $2}')
    if [ -n "$can_sim_pids" ]; then
        printc $yellow "Stopping CAN simulator processes: $can_sim_pids"
        echo $can_sim_pids | xargs kill -9 2>/dev/null || true
        sleep 1
    fi

    proclist="esync-boot"
    proclist="$proclist $app_restart__stop_apps"

    printc $yellow "kill $proclist"
    PROC_MAN="$ESYNC_HOME_DIR/bin/proc_man"
    pidlist=""
    for proc in $proclist; do
        pid=$("$PROC_MAN" -s $proc)
        if [ -z "$pid" ]; then
            printc $normal "$proc not running"
            continue
        fi
        printc $yellow "kill $pid $proc"
        kill $pid || true
        pidlist="$pidlist $pid"
    done

    # Wait for processes with timeout
    max_wait=30
    for pid in $pidlist; do
        waited=0
        while kill -0 $pid > /dev/null 2>&1; do
            if [ $waited -ge $max_wait ]; then
                printc $red "Timeout waiting for PID $pid, force killing"
                kill -9 $pid 2>/dev/null || true
                break
            fi
            printc $yellow "Waiting for PID $pid ($waited/$max_wait)"
            sleep 1
            waited=$((waited + 1))
        done
    done

    for pid in $("$PROC_MAN" -a loggit);
    do
        if ! kill -0 $pid > /dev/null 2>&1; then
            continue
        fi
        printc $yellow "Killing $pid loggit"
        kill -9 $pid
    done
}

stop_esync_only_for_selfupdate()
{
    PROC_MAN=${ESYNC_HOME_DIR}/bin/proc_man
    # Step 1: Kill all services FIRST (they're children of esync-boot)
    printc $yellow "Stopping services..."
    service_list="$app_restart__stop_apps"
    for proc in $service_list; do
        pid=$(${PROC_MAN} -s $proc)
        if [ -n "$pid" ]; then
            printc $yellow "kill $pid $proc"
            kill -9 "$pid" 2>/dev/null || true  
        fi
    done

    sleep 0.5
    # Step 2: Now kill esync-boot (it won't try to restart services)
    printc $yellow "Stopping esync-boot..."
    esync_boot_pid=$(${PROC_MAN} -s esync-boot)
    if [ -n "$esync_boot_pid" ]; then
        kill "$esync_boot_pid" 2>/dev/null || true
        timeout=4
        while [ $timeout -gt 0 ] && kill -0 "$esync_boot_pid" > /dev/null 2>&1; do
            sleep 0.5
            timeout=$((timeout - 1))
        done
        if kill -0 "$esync_boot_pid" > /dev/null 2>&1; then
            printc $red "Force killing esync-boot $esync_boot_pid"
            kill -9 "$esync_boot_pid" 2>/dev/null || true
            sleep 0.5
        fi
    fi
 
    printc $yellow "Cleaning up loggit processes..."
    for pid in $(${PROC_MAN} -a loggit); do 
        cmd=$(ps -p $pid -o cmd= 2>/dev/null)
 
        if echo "$cmd" | grep -Fq "selfupdateagent.log"; then
            printc $green "Skipping selfupdateagent.log (PID $pid)"
            continue
        fi
 
        if kill -0 "$pid" > /dev/null 2>&1; then
            printc $yellow "Killing $pid loggit ($cmd)"
            kill -9 "$pid" 2>/dev/null || true
        fi
    done
    printc $green "All processes stopped"
}

status()
{
    local quiet=false
    if [ "$1" = "-q" ]; then
        quiet=true
    fi

    proclist="esync-boot"
    if $START_CAN_SIM; then
        proclist="$proclist can_ecu_simulator"
    fi
    proclist="$proclist $app_restart__stop_apps"
    ok=true
    HM_STAT_FILE=$ESYNC_DATA_DIR
    
    MACHINE_DEVICE_ID=$(cat /etc/machine-id 2>/dev/null | tr '[:lower:]' '[:upper:]' | tr -d '\n')
       
    SDKVERSION="Version_Info_not_found"
    if [ -f $ESYNC_HOME_DIR/esync_version ];then
        SDKVERSION=$(cat $ESYNC_HOME_DIR/esync_version)
    fi
    
    if [ -n "$MACHINE_DEVICE_ID" ]; then
        $quiet || printc $cyan "**************************************"
        $quiet || printc $cyan "eSync Device ID (VIN): %s" $MACHINE_DEVICE_ID
    	$quiet || printc $cyan "eSync Release Version: %s" $SDKVERSION
    	$quiet || printc $cyan "**************************************"
    fi
    
    PROC_MAN=${ESYNC_HOME_DIR}/bin/proc_man
    $quiet || printc $normal "%-17s %-9s %-10s %-5s %10s" Process PID Time CPU Restarts
    for proc in $proclist; do
        pid=$("$PROC_MAN" -s $proc)
	# Fallback for CAN simulator if proc_man fails
        if [ -z "$pid" ] && [ "$proc" = "can_ecu_simulator" ]; then
            pid=$(ps aux | grep can_ecu_simulator | grep -v grep | awk '{print $2}' | head -1)
        fi
        
        if [ -z "$pid" ]; then
            $quiet || printc $red "%-16s %s %s" $proc not running
            ok=false
            continue
        fi
    if [ -f "$HM_STAT_FILE" ];then
        RETRY_COUNT=$(jq --arg my_proc "${proc}" -r '.[] | select(.app_name == $my_proc)' "$HM_STAT_FILE" | jq '.restart_count')
    fi

    if [ -z "$RETRY_COUNT" ];then
        $quiet || printc $green "%-16s %5s %10s %-15s %s" "$proc" "$pid" "$("$PROC_MAN" -e "$pid")" "$("$PROC_MAN" -c "$pid")" -
    else
        $quiet || printc $green "%-16s %5s %10s %-15s %s" "$proc" "$pid" "$("$PROC_MAN" -e "$pid")" "$("$PROC_MAN" -c "$pid")" "$RETRY_COUNT"
    fi
    done
    $ok
}

wait()
{
    numsecs=120
    for n in $(seq 1 $numsecs); do
        printf "."
        status -q && break
        sleep 1
    done
    echo
    status
}

IS_START=false
IS_STOP=false
IS_STOP_SELFUPDATE=false
SELF_UPDATE=false
IS_WAIT=false
IS_STATUS=false
DO_NOT_STOP=false
START_CAN_SIM=false
TEST_MODE=false
QUIET=""
VERBOSE=false

. "$THIS_DIR/sdk.cfg"
ES_HOME="$ESYNC_INSTALL_DIR/esync"
ES_DATA="$ESYNC_RUN_DIR"

while getopts "ho:d:l:sSkawqvbcQ" flag; do
    case $flag in
    o) ES_HOME=${OPTARG};;
    d) ES_DATA=${OPTARG};;
    l) ES_LOG=${OPTARG};;
    s) IS_START=true;;
    S) SELF_UPDATE=true;;
    k) IS_STOP=true;;
    a) IS_STOP_SELFUPDATE=true;;
    w) IS_WAIT=true;;
    q) QUIET="-q";;
    v) VERBOSE=true;;
    b) DO_NOT_STOP=true;;
    c) START_CAN_SIM=true;;
    Q) TEST_MODE=true;;
	*) print_usage; exit 1;;
    esac
done

if ! $IS_START && ! $IS_STOP && ! $IS_STOP_SELFUPDATE && ! $SELF_UPDATE && ! $IS_WAIT; then
    IS_STATUS=true
fi

. "$THIS_DIR/config.cfg"
export ESYNC_HOME_DIR="$ES_HOME"
export ESYNC_DATA_DIR="$ES_DATA"
export ESYNC_LOG_DIR="$ESYNC_LOG"
export ESYNC_DIR="$ES_HOME"
export PATH="$ESYNC_HOME_DIR/bin:$PATH"

export LD_LIBRARY_PATH="$ESYNC_HOME_DIR/lib:$LD_LIBRARY_PATH"

if $TEST_MODE; then
    BOOT_CFG="$ES_HOME/etc/esyncboot_test.json"
    printc $yellow "Test mode: using $BOOT_CFG"
else
    BOOT_CFG="$ES_HOME/etc/esyncboot.json"
fi

printc $normal "parse_json_cfg $BOOT_CFG"
parse_json_cfg $BOOT_CFG

if $SELF_UPDATE; then
    IS_START=true
fi

if $IS_START; then
    printc $green "eSync Starting..."
    if ! start; then
        printc $red "Error: Failed to start eSync"
        printc $red "Check logs at: $ESYNC_LOG_DIR/"
        exit 1
    fi
    # Note: Child services (agent, esyncbus, etc.) will be spawned by esync-boot
fi

if $IS_STOP; then
    printc $cyan "eSync Stopping..."
    stop
    printc $cyan "eSync Stopped."
fi

if $IS_STOP_SELFUPDATE; then
    printc $cyan "eSync Stopping..."
    stop_esync_only_for_selfupdate
    printc $cyan "eSync Stopped."
fi

if $IS_STATUS; then
    status $QUIET
fi

if $IS_WAIT; then
    PROC_MAN="$ESYNC_HOME_DIR/bin/proc_man"
    if $TEST_MODE; then
        printc $yellow "eSync Test Mode Starting"
        wait
        esyncbus_pid=$("$PROC_MAN" -s esyncbus 2>/dev/null)
        if [ -z "$esyncbus_pid" ]; then
            printc $red "========================================"
            printc $red "Test mode startup appears to have failed!"
            printc $red "========================================"
            printc $yellow "Please check the esync-boot log for details:"
            printc $cyan "  $ESYNC_LOG_DIR/esync_boot.log"
            printc $red "========================================"
        else
            printc $green "eSync test mode started successfully"
        fi
    else
        printc $yellow "eSync Provisioning"
        wait
        agent_pid=$("$PROC_MAN" -s agent 2>/dev/null)
        esyncbus_pid=$("$PROC_MAN" -s esyncbus 2>/dev/null)
        if [ -z "$agent_pid" ] || [ -z "$esyncbus_pid" ]; then
            printc $red "========================================"
            printc $red "Provisioning appears to have failed!"
            printc $red "========================================"
            printc $yellow "Please check the esync-boot log for details:"
            printc $cyan "  $ESYNC_LOG_DIR/esync_boot.log"
            printc $normal ""
            printc $yellow "Common issues to check:"
            printc $normal "  - Valid SECRET, APIKEY and DOMAIN URL in provision-key.json"
            printc $normal "  - Required outbound ports: TCP 443, TCP 8443"
            printc $normal "  - Check firewall rules if ports are blocked"
            printc $red "========================================"
        else
            printc $green "eSync provisioning completed successfully"
        fi
    fi
fi

if $DO_NOT_STOP; then
    while true; do
        sleep 60
    done
fi

