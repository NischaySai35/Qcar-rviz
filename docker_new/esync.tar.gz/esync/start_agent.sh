#!/bin/bash
# Template Agent Start/Stop Script for Two RPI Setup
# Copyright Excelfore Corporation

THIS_DIR="$(realpath $(dirname $0))"
rdc='\033[0;31m'; grc='\033[0;32m'; ywc='\033[1;33m'; nc='\033[0m'

usage() {
cat <<USAGE
Usage options:
 ./start_agent.sh start UA        # Start template agent on board 1
 ./start_agent.sh stop UA         # Stop template agent on board 1  
 ./start_agent.sh start UA BOARD2 # Start template agent on board 2
 ./start_agent.sh stop UA BOARD2  # Stop template agent on board 2
 ./start_agent.sh -h              # Help

USAGE
}

dependencies_check() {
    if [ ! -f "$THIS_DIR/config.cfg" ]; then
        printf "$rdc [Error !] config.cfg file not present in $THIS_DIR $nc \n" && exit 1
    fi
    
    . "$THIS_DIR/config.cfg"
    
    # Always source SDK config for proper paths
    if [ -f "$THIS_DIR/../sdk.cfg" ]; then
        . "$THIS_DIR/../sdk.cfg"
    fi
    
    if [ ! -z "$OP3" ] && [ ! -f "$THIS_DIR/config_rpi.cfg" ]; then
        printf "$rdc [Error !] config_rpi.cfg file not present in $THIS_DIR $nc \n" && exit 1
    fi
    
    if [ ! -z "$OP3" ]; then
        . "$THIS_DIR/config_rpi.cfg"
        if [ ! -z "$RPI_IP" ] && [ ! -z "$PORT_ADDRESS" ]; then
            tcpConnection="tcp://$RPI_IP:$PORT_ADDRESS"
        else
            printf "$rdc RPI_IP or PORT_ADDRESS empty in config file $nc \n" && exit 1
        fi
    fi
    
    
    # Create log directory only if ESYNC_RUN_DIR is accessible locally
    if [ -w "$(dirname "$ESYNC_RUN_DIR")" ] 2>/dev/null || [ -d "$ESYNC_RUN_DIR" ]; then
        mkdir -p "$ESYNC_RUN_DIR/log" 2>/dev/null || true
    fi
}

pid() {
    UA_PID=$(ps -aux | grep $TMPL_UA_BIN_NAME | grep -v grep | awk '{print $2}')
}

check_certs() {
    if [ "$1" == "UA" ]; then
        # Source the SDK config to get proper paths
        if [ -f "$THIS_DIR/../sdk.cfg" ]; then
            . "$THIS_DIR/../sdk.cfg"
        fi
        
        CERT_PATH="$ESYNC_RUN_DIR/InVehicle-Certs/pki/certs/$TMPL_UA_CERTS_NAME"
        if [ -f "$CERT_PATH/private.pem" ] && 
           [ -f "$CERT_PATH/cert.pem" ] && 
           [ -f "$CERT_PATH/ca.conf" ]; then
            printf "$grc $TMPL_UA_CERTS_NAME Certificates are present on hardware $nc \n"
        else
            printf "$rdc [Error!] Certificates not found at $CERT_PATH $nc \n" && exit 1
        fi
    fi
}

start_agent() {
    check_certs "$1"
    stop_agent "$1"
    
    ESYNC_TMPL_UA="$ESYNC_DIR/bin/$TMPL_UA_BIN_NAME"
    tmpl_ua_args="-k $ESYNC_RUN_DIR/InVehicle-Certs/pki/certs/$TMPL_UA_CERTS_NAME -t $TMPL_UA_PKG_TYPE -b $ESYNC_RUN_DIR/ -i -D"
    ESYNC_LOG_DIR="$ESYNC_RUN_DIR/log"
    export LD_LIBRARY_PATH="$ESYNC_DIR/lib:$LD_LIBRARY_PATH"
    
    printf "Starting custom agent...\n"
    if [ "$1" = "UA" ]; then
        if [ -f "$ESYNC_DIR/bin/$TMPL_UA_BIN_NAME" ] && [ -z "$OP3" ]; then
            # Board 1 - local connection
            nohup $ESYNC_TMPL_UA $tmpl_ua_args > "$ESYNC_LOG_DIR/$TMPL_UA_BIN_NAME.log" 2>&1 &
        elif [ -f "$ESYNC_DIR/bin/$TMPL_UA_BIN_NAME" ] && [ "$OP3" == "BOARD2" ]; then
            # Board 2 - remote connection to board 1
            nohup $ESYNC_TMPL_UA $tmpl_ua_args -u "$tcpConnection" > "$ESYNC_LOG_DIR/$TMPL_UA_BIN_NAME.log" 2>&1 &
        else
            printf "Template agent not found (expected during reset) \n"
        fi
    else
        usage
        exit 1
    fi
}

stop_agent() {
    pid
    if [ "$1" == "UA" ] && [ ! -z "$UA_PID" ]; then
        kill -9 $UA_PID
    elif [ -z "$UA_PID" ]; then
        printf "Custom agent is not running \n"
    fi
}

user_install_path() {
    if [ "$OP1" = 'start' ]; then
        start_agent "$OP2"
    elif [ "$OP1" = 'stop' ]; then
        stop_agent "$OP2"
    elif [ "$OP1" = '-h' ]; then
        usage
    else
        usage
        exit 1
    fi
}

# Source SDK configuration first to get proper paths
if [ -f "$THIS_DIR/../sdk.cfg" ]; then
    . "$THIS_DIR/../sdk.cfg"
elif [ -f "$THIS_DIR/sdk.cfg" ]; then
    . "$THIS_DIR/sdk.cfg"
fi

# Parse command line arguments
if [ $# -eq 1 ]; then
    OP1="$1"
    OP2="UA"
    dependencies_check
    user_install_path
elif [ $# -eq 2 ]; then
    OP1="$1"
    OP2="$2"
    dependencies_check
    user_install_path
elif [ $# -eq 3 ]; then
    OP1="$1"
    OP2="$2"
    OP3="$3"
    dependencies_check
    user_install_path
else
    echo "Help Options:"
    usage
    exit 1
fi